function fibonacci(num1,num2)
        {
            var num = 0;
            var proximo_num = 1;
            var aux;
            num1.value = "";

            while ( num <= num2.value )
            {
                num1.value += num+", ";
                aux = proximo_num;
                proximo_num = proximo_num + num;
                num = aux;
            }
        }