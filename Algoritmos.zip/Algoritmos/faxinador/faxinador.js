var pessoas =  
        {
            fizz: 'buzz',
            foo: null,
            bar: 42

        }
        const removeEmptyAttrs = (pessoas) => {

            Object.keys(pessoas).forEach(key => {
                 if (pessoas[key] && typeof pessoas[key] === 'object')
                 {
                      removeEmptyAttrs(pessoas[key]);
                       if (Object.keys(pessoas[key]).length === 0){ 
                           delete pessoas[key]; 
                        }}
                        
                        else if (pessoas[key] === null) delete pessoas[key];
  });
};
        console.log('antes', pessoas);

        removeEmptyAttrs(pessoas);
        console.log('depois', pessoas);

        